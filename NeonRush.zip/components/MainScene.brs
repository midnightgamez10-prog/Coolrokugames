sub init()
    m.top.setFocus(true)

    ' Node refs
    m.bg = m.top.findNode("bg")
    m.stars = m.top.findNode("stars")
    m.world = m.top.findNode("world")
    m.playerGroup = m.top.findNode("playerGroup")
    m.player = m.top.findNode("player")
    m.playerGlow = m.top.findNode("playerGlow")
    m.particles = m.top.findNode("particles")
    m.levelLabel = m.top.findNode("levelLabel")
    m.nameLabel = m.top.findNode("nameLabel")
    m.attemptLabel = m.top.findNode("attemptLabel")
    m.progressLabel = m.top.findNode("progressLabel")
    m.progFill = m.top.findNode("progFill")
    m.overlay = m.top.findNode("overlay")
    m.titleLabel = m.top.findNode("titleLabel")
    m.subtitleLabel = m.top.findNode("subtitleLabel")
    m.msgLabel = m.top.findNode("msgLabel")
    m.hintLabel = m.top.findNode("hintLabel")
    m.detailLabel = m.top.findNode("detailLabel")

    ' Game state
    m.state = "title"
    m.currentLevel = 0
    m.attempt = 1
    m.totalAttempts = 0
    m.bestProgress = 0
    m.levels = buildLevels()

    ' Physics
    m.groundY = 920
    m.pSize = 44
    m.px = 300.0
    m.py = m.groundY - m.pSize
    m.vy = 0.0
    m.onGround = true
    m.gravity = 1.05
    m.jumpPower = -17.8
    m.jumpHeld = false
    m.jumpBuffer = 0
    m.coyote = 0
    m.scrollSpeed = 10.2
    m.worldX = 0.0
    m.shake = 0
    m.trailTimer = 0

    ' Colors per world
    m.themeColors = [
        {bg:"0x07071a", player:"0x00e5ff", accent:"0x00e5ff", platform:"0x1a1a3a", spike:"0xff3366"},
        {bg:"0x0a120a", player:"0x66ff99", accent:"0x66ff99", platform:"0x1a2a1a", spike:"0xff6644"},
        {bg:"0x120a18", player:"0xff66cc", accent:"0xff66cc", platform:"0x2a1a2a", spike:"0xffaa33"},
        {bg:"0x0a0a18", player:"0xaaccff", accent:"0xaaccff", platform:"0x1a1a2e", spike:"0xff4477"},
        {bg:"0x140808", player:"0xffaa44", accent:"0xffaa44", platform:"0x2a1a12", spike:"0xff2255"}
    ]

    createStarfield()
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.repeat = true
    m.timer.duration = 0.033
    m.timer.observeField("fire", "onTick")
    m.timer.control = "start"

    showTitle()
end sub

sub createStarfield()
    for i = 0 to 55
        s = CreateObject("roSGNode", "Rectangle")
        size = 2 + Rnd(3)
        s.width = size
        s.height = size
        s.translation = [Rnd(1920), Rnd(900)]
        s.color = "0xffffff"
        s.opacity = 0.15 + Rnd(40) / 100.0
        m.stars.appendChild(s)
    end for
end sub

' ============================================================
' LEVELS - detailed sequences
' ============================================================
function buildLevels() as Object
    L = []

    ' WORLD 1 - Cyan
    L.push({
        name: "First Pulse"
        world: 0
        length: 3800
        speed: 9.8
        objects: [
            {t:"floor", x:0, y:920, w:3800, h:160},
            {t:"spike", x:620, y:880, w:36, h:40},
            {t:"spike", x:780, y:880, w:36, h:40},
            {t:"plat", x:1000, y:800, w:160, h:28},
            {t:"spike", x:1300, y:880, w:36, h:40},
            {t:"plat", x:1500, y:740, w:150, h:28},
            {t:"spike", x:1800, y:880, w:36, h:40},
            {t:"spike", x:1920, y:880, w:36, h:40},
            {t:"plat", x:2150, y:780, w:170, h:28},
            {t:"bounce", x:2450, y:880, w:70, h:24},
            {t:"plat", x:2700, y:700, w:160, h:28},
            {t:"spike", x:3000, y:880, w:36, h:40},
            {t:"goal", x:3400, y:840, w:70, h:80}
        ]
    })

    L.push({
        name: "Rising Neon"
        world: 0
        length: 4500
        speed: 10.2
        objects: [
            {t:"floor", x:0, y:920, w:4500, h:160},
            {t:"spike", x:550, y:880, w:34, h:40},
            {t:"plat", x:750, y:820, w:130, h:26},
            {t:"spike", x:1000, y:880, w:34, h:40},
            {t:"plat", x:1200, y:760, w:130, h:26},
            {t:"spike", x:1480, y:880, w:34, h:40},
            {t:"spike", x:1580, y:880, w:34, h:40},
            {t:"plat", x:1800, y:720, w:140, h:26},
            {t:"bounce", x:2100, y:880, w:70, h:24},
            {t:"plat", x:2350, y:680, w:150, h:26},
            {t:"spike", x:2650, y:880, w:34, h:40},
            {t:"plat", x:2850, y:760, w:130, h:26},
            {t:"spike", x:3150, y:880, w:34, h:40},
            {t:"spike", x:3250, y:880, w:34, h:40},
            {t:"plat", x:3500, y:700, w:160, h:26},
            {t:"goal", x:4100, y:840, w:70, h:80}
        ]
    })

    ' WORLD 2 - Green
    L.push({
        name: "Emerald Trail"
        world: 1
        length: 5000
        speed: 10.6
        objects: [
            {t:"floor", x:0, y:920, w:5000, h:160},
            {t:"spike", x:500, y:880, w:34, h:40},
            {t:"plat", x:700, y:810, w:120, h:26},
            {t:"block", x:1000, y:800, w:48, h:120},
            {t:"spike", x:1200, y:880, w:34, h:40},
            {t:"plat", x:1400, y:740, w:130, h:26},
            {t:"spike", x:1700, y:880, w:34, h:40},
            {t:"spike", x:1800, y:880, w:34, h:40},
            {t:"bounce", x:2000, y:880, w:70, h:24},
            {t:"plat", x:2250, y:680, w:140, h:26},
            {t:"block", x:2550, y:780, w:48, h:140},
            {t:"spike", x:2750, y:880, w:34, h:40},
            {t:"plat", x:2950, y:720, w:130, h:26},
            {t:"spike", x:3250, y:880, w:34, h:40},
            {t:"plat", x:3500, y:660, w:150, h:26},
            {t:"spike", x:3800, y:880, w:34, h:40},
            {t:"spike", x:3900, y:880, w:34, h:40},
            {t:"goal", x:4500, y:840, w:70, h:80}
        ]
    })

    L.push({
        name: "Forest Rush"
        world: 1
        length: 5400
        speed: 11.0
        objects: [
            {t:"floor", x:0, y:920, w:5400, h:160},
            {t:"plat", x:500, y:820, w:110, h:24},
            {t:"spike", x:750, y:880, w:32, h:40},
            {t:"plat", x:950, y:760, w:110, h:24},
            {t:"spike", x:1200, y:880, w:32, h:40},
            {t:"block", x:1400, y:790, w:46, h:130},
            {t:"plat", x:1650, y:700, w:120, h:24},
            {t:"spike", x:1950, y:880, w:32, h:40},
            {t:"spike", x:2050, y:880, w:32, h:40},
            {t:"bounce", x:2250, y:880, w:70, h:24},
            {t:"plat", x:2500, y:660, w:130, h:24},
            {t:"spike", x:2800, y:880, w:32, h:40},
            {t:"plat", x:3000, y:740, w:110, h:24},
            {t:"block", x:3300, y:780, w:46, h:140},
            {t:"spike", x:3550, y:880, w:32, h:40},
            {t:"plat", x:3800, y:680, w:140, h:24},
            {t:"spike", x:4150, y:880, w:32, h:40},
            {t:"spike", x:4250, y:880, w:32, h:40},
            {t:"goal", x:4900, y:840, w:70, h:80}
        ]
    })

    ' WORLD 3 - Magenta
    L.push({
        name: "Pink Voltage"
        world: 2
        length: 5600
        speed: 11.3
        objects: [
            {t:"floor", x:0, y:920, w:5600, h:160},
            {t:"spike", x:480, y:880, w:32, h:40},
            {t:"plat", x:680, y:800, w:110, h:24},
            {t:"spike", x:950, y:880, w:32, h:40},
            {t:"plat", x:1150, y:740, w:110, h:24},
            {t:"block", x:1450, y:780, w:46, h:140},
            {t:"spike", x:1650, y:880, w:32, h:40},
            {t:"bounce", x:1850, y:880, w:70, h:24},
            {t:"plat", x:2100, y:680, w:130, h:24},
            {t:"spike", x:2400, y:880, w:32, h:40},
            {t:"spike", x:2500, y:880, w:32, h:40},
            {t:"plat", x:2700, y:720, w:120, h:24},
            {t:"block", x:3000, y:760, w:46, h:160},
            {t:"spike", x:3250, y:880, w:32, h:40},
            {t:"plat", x:3500, y:660, w:140, h:24},
            {t:"spike", x:3850, y:880, w:32, h:40},
            {t:"plat", x:4100, y:700, w:130, h:24},
            {t:"spike", x:4450, y:880, w:32, h:40},
            {t:"spike", x:4550, y:880, w:32, h:40},
            {t:"goal", x:5100, y:840, w:70, h:80}
        ]
    })

    L.push({
        name: "Hyper Circuit"
        world: 2
        length: 6000
        speed: 11.6
        objects: [
            {t:"floor", x:0, y:920, w:6000, h:160},
            {t:"plat", x:450, y:810, w:100, h:24},
            {t:"spike", x:700, y:880, w:30, h:40},
            {t:"plat", x:900, y:750, w:100, h:24},
            {t:"spike", x:1150, y:880, w:30, h:40},
            {t:"block", x:1350, y:780, w:44, h:140},
            {t:"bounce", x:1600, y:880, w:70, h:24},
            {t:"plat", x:1850, y:680, w:120, h:24},
            {t:"spike", x:2150, y:880, w:30, h:40},
            {t:"spike", x:2250, y:880, w:30, h:40},
            {t:"plat", x:2450, y:720, w:110, h:24},
            {t:"block", x:2750, y:760, w:44, h:160},
            {t:"spike", x:3000, y:880, w:30, h:40},
            {t:"plat", x:3200, y:660, w:130, h:24},
            {t:"spike", x:3550, y:880, w:30, h:40},
            {t:"plat", x:3800, y:700, w:120, h:24},
            {t:"block", x:4100, y:780, w:44, h:140},
            {t:"spike", x:4350, y:880, w:30, h:40},
            {t:"spike", x:4450, y:880, w:30, h:40},
            {t:"plat", x:4700, y:640, w:150, h:24},
            {t:"goal", x:5500, y:840, w:70, h:80}
        ]
    })

    ' WORLD 4 - Blue
    L.push({
        name: "Deep Current"
        world: 3
        length: 6200
        speed: 11.9
        objects: [
            {t:"floor", x:0, y:920, w:6200, h:160},
            {t:"spike", x:450, y:880, w:30, h:40},
            {t:"plat", x:650, y:800, w:100, h:24},
            {t:"spike", x:920, y:880, w:30, h:40},
            {t:"plat", x:1120, y:740, w:100, h:24},
            {t:"block", x:1400, y:770, w:44, h:150},
            {t:"spike", x:1650, y:880, w:30, h:40},
            {t:"bounce", x:1850, y:880, w:70, h:24},
            {t:"plat", x:2100, y:660, w:120, h:24},
            {t:"spike", x:2450, y:880, w:30, h:40},
            {t:"spike", x:2550, y:880, w:30, h:40},
            {t:"plat", x:2750, y:700, w:110, h:24},
            {t:"block", x:3050, y:750, w:44, h:170},
            {t:"spike", x:3300, y:880, w:30, h:40},
            {t:"plat", x:3550, y:640, w:130, h:24},
            {t:"spike", x:3900, y:880, w:30, h:40},
            {t:"plat", x:4150, y:680, w:120, h:24},
            {t:"spike", x:4500, y:880, w:30, h:40},
            {t:"spike", x:4600, y:880, w:30, h:40},
            {t:"bounce", x:4800, y:880, w:70, h:24},
            {t:"plat", x:5100, y:620, w:150, h:24},
            {t:"goal", x:5700, y:840, w:70, h:80}
        ]
    })

    ' WORLD 5 - Orange finale
    L.push({
        name: "Solar Flare"
        world: 4
        length: 6800
        speed: 12.2
        objects: [
            {t:"floor", x:0, y:920, w:6800, h:160},
            {t:"plat", x:400, y:810, w:100, h:24},
            {t:"spike", x:650, y:880, w:30, h:40},
            {t:"plat", x:850, y:750, w:100, h:24},
            {t:"spike", x:1120, y:880, w:30, h:40},
            {t:"block", x:1320, y:770, w:44, h:150},
            {t:"bounce", x:1580, y:880, w:70, h:24},
            {t:"plat", x:1820, y:660, w:120, h:24},
            {t:"spike", x:2150, y:880, w:30, h:40},
            {t:"spike", x:2250, y:880, w:30, h:40},
            {t:"plat", x:2450, y:700, w:110, h:24},
            {t:"block", x:2750, y:740, w:44, h:180},
            {t:"spike", x:3000, y:880, w:30, h:40},
            {t:"plat", x:3200, y:640, w:130, h:24},
            {t:"spike", x:3550, y:880, w:30, h:40},
            {t:"plat", x:3800, y:680, w:120, h:24},
            {t:"block", x:4100, y:760, w:44, h:160},
            {t:"spike", x:4350, y:880, w:30, h:40},
            {t:"spike", x:4450, y:880, w:30, h:40},
            {t:"bounce", x:4650, y:880, w:70, h:24},
            {t:"plat", x:4900, y:620, w:140, h:24},
            {t:"spike", x:5250, y:880, w:30, h:40},
            {t:"plat", x:5500, y:660, w:150, h:24},
            {t:"spike", x:5850, y:880, w:30, h:40},
            {t:"spike", x:5950, y:880, w:30, h:40},
            {t:"goal", x:6400, y:840, w:70, h:80}
        ]
    })

    return L
end function

' ============================================================
' MENUS
' ============================================================
sub showTitle()
    m.state = "title"
    m.overlay.visible = true
    m.overlay.opacity = 0.82
    m.titleLabel.text = "NEON RUSH"
    m.titleLabel.visible = true
    m.subtitleLabel.text = "A detailed Roku action game"
    m.subtitleLabel.visible = true
    m.msgLabel.text = "Press OK to Start"
    m.msgLabel.visible = true
    m.hintLabel.visible = true
    m.detailLabel.text = "8 levels  •  5 worlds  •  bounce pads  •  solid blocks  •  precise jumps"
    m.detailLabel.visible = true
    m.levelLabel.text = ""
    m.nameLabel.text = ""
    m.attemptLabel.text = ""
    m.progressLabel.text = ""
    m.progFill.width = 0
end sub

sub startLevel(idx as Integer)
    if idx < 0 or idx >= m.levels.count() then
        showComplete()
        return
    end if

    m.currentLevel = idx
    level = m.levels[idx]
    theme = m.themeColors[level.world]

    m.bg.color = theme.bg
    m.player.color = theme.player
    m.playerGlow.color = theme.player
    m.playerGlow.opacity = 0.28

    m.attempt = 1
    m.totalAttempts = m.totalAttempts + 1
    m.worldX = 0
    m.vy = 0
    m.onGround = true
    m.jumpHeld = false
    m.jumpBuffer = 0
    m.coyote = 0
    m.shake = 0
    m.scrollSpeed = level.speed
    m.py = m.groundY - m.pSize
    m.playerGroup.translation = [m.px, m.py]

    ' clear world + particles
    while m.world.getChildCount() > 0
        m.world.removeChildIndex(0)
    end while
    while m.particles.getChildCount() > 0
        m.particles.removeChildIndex(0)
    end while

    m.platforms = []
    m.spikes = []
    m.blocks = []
    m.bounces = []
    m.goal = invalid

    for each o in level.objects
        if o.t = "floor" or o.t = "plat" then
            r = CreateObject("roSGNode", "Rectangle")
            r.width = o.w : r.height = o.h
            r.translation = [o.x, o.y]
            r.color = theme.platform
            m.world.appendChild(r)
            m.platforms.push({x:o.x, y:o.y, w:o.w, h:o.h})
        else if o.t = "spike" then
            r = CreateObject("roSGNode", "Rectangle")
            r.width = o.w : r.height = o.h
            r.translation = [o.x, o.y]
            r.color = theme.spike
            m.world.appendChild(r)
            m.spikes.push({x:o.x, y:o.y, w:o.w, h:o.h})
        else if o.t = "block" then
            r = CreateObject("roSGNode", "Rectangle")
            r.width = o.w : r.height = o.h
            r.translation = [o.x, o.y]
            r.color = "0x3a3a5a"
            m.world.appendChild(r)
            m.blocks.push({x:o.x, y:o.y, w:o.w, h:o.h})
        else if o.t = "bounce" then
            r = CreateObject("roSGNode", "Rectangle")
            r.width = o.w : r.height = o.h
            r.translation = [o.x, o.y]
            r.color = "0xffee55"
            m.world.appendChild(r)
            m.bounces.push({x:o.x, y:o.y, w:o.w, h:o.h})
        else if o.t = "goal" then
            r = CreateObject("roSGNode", "Rectangle")
            r.width = o.w : r.height = o.h
            r.translation = [o.x, o.y]
            r.color = "0x00ff88"
            m.world.appendChild(r)
            ' flag pole
            pole = CreateObject("roSGNode", "Rectangle")
            pole.width = 8 : pole.height = o.h + 30
            pole.translation = [o.x + o.w/2 - 4, o.y - 30]
            pole.color = "0xffffff"
            m.world.appendChild(pole)
            m.goal = {x:o.x, y:o.y, w:o.w, h:o.h}
        end if
    end for

    m.levelLength = level.length
    m.overlay.visible = false
    m.titleLabel.visible = false
    m.subtitleLabel.visible = false
    m.msgLabel.visible = false
    m.hintLabel.visible = false
    m.detailLabel.visible = false
    m.levelLabel.text = "LEVEL " + (idx+1).toStr()
    m.nameLabel.text = level.name
    m.attemptLabel.text = "Attempt " + m.attempt.toStr()
    m.progressLabel.text = "0%"
    m.progFill.width = 0
    m.progFill.color = theme.accent
    m.state = "playing"
end sub

sub die()
    m.state = "dead"
    m.player.color = "0xff4444"
    m.playerGlow.color = "0xff4444"
    m.shake = 14
    spawnDeathParticles()
    m.attempt = m.attempt + 1
    m.totalAttempts = m.totalAttempts + 1
    m.overlay.visible = true
    m.overlay.opacity = 0.7
    m.titleLabel.text = "CRASHED"
    m.titleLabel.visible = true
    m.subtitleLabel.visible = false
    m.msgLabel.text = "Press OK to retry"
    m.msgLabel.visible = true
    m.hintLabel.visible = false
    m.detailLabel.text = "Attempt " + m.attempt.toStr()
    m.detailLabel.visible = true
end sub

sub showWon()
    m.state = "won"
    m.overlay.visible = true
    m.overlay.opacity = 0.75
    m.titleLabel.text = "LEVEL CLEAR"
    m.titleLabel.visible = true
    m.subtitleLabel.text = m.levels[m.currentLevel].name
    m.subtitleLabel.visible = true
    m.msgLabel.text = "Press OK for next level"
    m.msgLabel.visible = true
    m.hintLabel.visible = false
    m.detailLabel.text = "Attempts this level: " + m.attempt.toStr()
    m.detailLabel.visible = true
end sub

sub showComplete()
    m.state = "complete"
    m.overlay.visible = true
    m.overlay.opacity = 0.85
    m.titleLabel.text = "YOU BEAT NEON RUSH"
    m.titleLabel.visible = true
    m.subtitleLabel.text = "All 8 levels cleared"
    m.subtitleLabel.visible = true
    m.msgLabel.text = "Press OK to play again"
    m.msgLabel.visible = true
    m.hintLabel.visible = false
    m.detailLabel.text = "Total attempts: " + m.totalAttempts.toStr()
    m.detailLabel.visible = true
end sub

' ============================================================
' PARTICLES
' ============================================================
sub spawnDeathParticles()
    for i = 0 to 12
        p = CreateObject("roSGNode", "Rectangle")
        sz = 4 + Rnd(8)
        p.width = sz : p.height = sz
        p.translation = [m.px + Rnd(30) - 15, m.py + Rnd(30) - 15]
        p.color = "0xff4466"
        p.opacity = 0.9
        m.particles.appendChild(p)
    end for
end sub

sub spawnTrail()
    p = CreateObject("roSGNode", "Rectangle")
    p.width = 10 : p.height = 10
    p.translation = [m.px + 12, m.py + 18]
    p.color = m.player.color
    p.opacity = 0.45
    m.particles.appendChild(p)
end sub

sub updateParticles()
    ' simple fade + remove
    i = 0
    while i < m.particles.getChildCount()
        p = m.particles.getChild(i)
        p.opacity = p.opacity - 0.06
        if p.opacity <= 0 then
            m.particles.removeChildIndex(i)
        else
            ' drift
            t = p.translation
            p.translation = [t[0] - 2, t[1] - 1]
            i = i + 1
        end if
    end while
end sub

' ============================================================
' GAME LOOP
' ============================================================
sub onTick()
    if m.state = "title" then
        ' gentle star drift
        return
    end if

    if m.state <> "playing" then
        updateParticles()
        if m.shake > 0 then
            m.shake = m.shake - 1
            m.world.translation = [-m.worldX + (Rnd(10)-5), Rnd(8)-4]
        end if
        return
    end if

    ' Auto scroll
    m.worldX = m.worldX + m.scrollSpeed
    shakeX = 0
    shakeY = 0
    if m.shake > 0 then
        m.shake = m.shake - 1
        shakeX = Rnd(8) - 4
        shakeY = Rnd(6) - 3
    end if
    m.world.translation = [-m.worldX + shakeX, shakeY]

    ' Variable jump
    if m.jumpHeld and m.vy < 0 then
        m.vy = m.vy + m.gravity * 0.35   ' slower fall while holding
    else
        m.vy = m.vy + m.gravity
    end if
    if m.vy > 24 then m.vy = 24

    ' Coyote + buffer
    if m.onGround then m.coyote = 6
    if m.coyote > 0 then m.coyote = m.coyote - 1
    if m.jumpBuffer > 0 then
        m.jumpBuffer = m.jumpBuffer - 1
        if m.coyote > 0 then
            doJump()
            m.jumpBuffer = 0
        end if
    end if

    newY = m.py + m.vy
    m.onGround = false
    worldPX = m.worldX + m.px
    pw = m.pSize
    ph = m.pSize

    ' Platforms
    for each p in m.platforms
        if worldPX + pw > p.x and worldPX < p.x + p.w then
            if m.vy >= 0 and m.py + ph <= p.y + 10 and newY + ph >= p.y then
                newY = p.y - ph
                m.vy = 0
                m.onGround = true
            end if
        end if
    end for

    ' Blocks
    for each b in m.blocks
        if worldPX + pw > b.x and worldPX < b.x + b.w then
            if m.vy >= 0 and m.py + ph <= b.y + 10 and newY + ph >= b.y then
                newY = b.y - ph
                m.vy = 0
                m.onGround = true
            else if newY + ph > b.y + 4 and newY < b.y + b.h then
                die()
                return
            end if
        end if
    end for

    ' Bounce pads
    for each b in m.bounces
        if worldPX + pw > b.x and worldPX < b.x + b.w then
            if m.vy >= 0 and m.py + ph <= b.y + 12 and newY + ph >= b.y then
                newY = b.y - ph
                m.vy = -22.5   ' big bounce
                m.onGround = false
                m.shake = 4
            end if
        end if
    end for

    m.py = newY
    m.playerGroup.translation = [m.px, m.py]

    if m.py > 1150 then
        die()
        return
    end if

    ' Spikes
    for each s in m.spikes
        if aabb(worldPX, m.py, pw, ph, s.x, s.y, s.w, s.h) then
            die()
            return
        end if
    end for

    ' Goal
    if m.goal <> invalid then
        if aabb(worldPX, m.py, pw, ph, m.goal.x, m.goal.y, m.goal.w, m.goal.h) then
            showWon()
            return
        end if
    end if

    ' Trail
    m.trailTimer = m.trailTimer + 1
    if m.trailTimer >= 3 then
        m.trailTimer = 0
        if not m.onGround then spawnTrail()
    end if
    updateParticles()

    ' Progress
    pct = Int((m.worldX / m.levelLength) * 100)
    if pct > 100 then pct = 100
    if pct > m.bestProgress then m.bestProgress = pct
    m.progressLabel.text = pct.toStr() + "%"
    m.progFill.width = Int(600 * (pct / 100.0))
end sub

function aabb(x1, y1, w1, h1, x2, y2, w2, h2) as Boolean
    return x1 < x2 + w2 and x1 + w1 > x2 and y1 < y2 + h2 and y1 + h1 > y2
end function

sub doJump()
    if m.coyote > 0 or m.onGround then
        m.vy = m.jumpPower
        m.onGround = false
        m.coyote = 0
        m.jumpHeld = true
    else
        m.jumpBuffer = 8
    end if
end sub

' ============================================================
' INPUT
' ============================================================
function onKeyEvent(key as String, press as Boolean) as Boolean
    if key = "OK" or key = "up" or key = "A" or key = "play" then
        if press then
            if m.state = "title" then
                startLevel(0)
            else if m.state = "dead" then
                startLevel(m.currentLevel)
            else if m.state = "won" then
                startLevel(m.currentLevel + 1)
            else if m.state = "complete" then
                m.totalAttempts = 0
                startLevel(0)
            else if m.state = "playing" then
                doJump()
            end if
        else
            m.jumpHeld = false
        end if
        return true
    else if key = "back" and press then
        if m.state <> "title" then
            showTitle()
            return true
        end if
    else if (key = "B" or key = "replay" or key = "options") and press then
        if m.state = "playing" or m.state = "dead" then
            startLevel(m.currentLevel)
            return true
        end if
    end if
    return false
end function
