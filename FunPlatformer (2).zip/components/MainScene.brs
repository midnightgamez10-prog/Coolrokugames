sub init()
    m.top.setFocus(true)

    ' Node refs
    m.world = m.top.findNode("world")
    m.player = m.top.findNode("player")
    m.scoreLabel = m.top.findNode("scoreLabel")
    m.livesLabel = m.top.findNode("livesLabel")
    m.levelLabel = m.top.findNode("levelLabel")
    m.overlay = m.top.findNode("overlay")
    m.titleLabel = m.top.findNode("titleLabel")
    m.msgLabel = m.top.findNode("msgLabel")
    m.controlsLabel = m.top.findNode("controlsLabel")

    ' Game state
    m.state = "title"   ' title | playing | dead | won | complete
    m.score = 0
    m.lives = 3
    m.currentLevel = 0
    m.levels = getLevels()

    ' Physics
    m.px = 200.0
    m.py = 700.0
    m.vx = 0.0
    m.vy = 0.0
    m.onGround = false
    m.facing = 1
    m.gravity = 0.72
    m.jumpPower = -15.5
    m.moveSpeed = 7.5
    m.friction = 0.78

    ' Input
    m.keys = {}
    m.keys["left"] = false
    m.keys["right"] = false
    m.keys["jump"] = false

    ' Timer for game loop (~60fps feel, but Roku is slower so we use 30-40ms)
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.repeat = true
    m.timer.duration = 0.033
    m.timer.observeField("fire", "onTick")
    m.timer.control = "start"

    showTitle()
end sub

' ============================================================
' LEVEL DATA
' ============================================================
function getLevels() as Object
    levels = []

    ' Level 1 - Tutorial (easy, low platforms)
    levels.push({
        name: "Getting Started"
        startX: 100
        startY: 850
        platforms: [
            {x:0, y:950, w:1920, h:130}       ' ground
            {x:350, y:820, w:220, h:30}
            {x:650, y:720, w:200, h:30}
            {x:950, y:820, w:200, h:30}
            {x:1250, y:720, w:220, h:30}
            {x:1550, y:820, w:250, h:30}
        ]
        coins: [
            {x:430, y:760}, {x:720, y:660}, {x:1020, y:760},
            {x:1330, y:660}, {x:1650, y:760}
        ]
        spikes: [
            {x:880, y:920, w:60, h:30}
        ]
        goal: {x:1700, y:740, w:60, h:80}
    })

    ' Level 2 - Rising path
    levels.push({
        name: "Rising Path"
        startX: 80
        startY: 850
        platforms: [
            {x:0, y:950, w:350, h:130}
            {x:420, y:860, w:160, h:28}
            {x:650, y:780, w:160, h:28}
            {x:880, y:700, w:160, h:28}
            {x:1110, y:780, w:160, h:28}
            {x:1340, y:700, w:160, h:28}
            {x:1570, y:620, w:200, h:28}
            {x:1400, y:520, w:180, h:28}
        ]
        coins: [
            {x:480, y:800}, {x:710, y:720}, {x:940, y:640},
            {x:1170, y:720}, {x:1400, y:640}, {x:1650, y:560},
            {x:1470, y:460}
        ]
        spikes: [
            {x:370, y:920, w:40, h:30},
            {x:820, y:920, w:50, h:30},
            {x:1280, y:920, w:50, h:30}
        ]
        goal: {x:1460, y:440, w:60, h:80}
    })

    ' Level 3 - Gaps
    levels.push({
        name: "Mind the Gap"
        startX: 80
        startY: 800
        platforms: [
            {x:0, y:920, w:280, h:160}
            {x:360, y:850, w:140, h:28}
            {x:580, y:780, w:130, h:28}
            {x:800, y:850, w:130, h:28}
            {x:1020, y:780, w:140, h:28}
            {x:1250, y:700, w:150, h:28}
            {x:1500, y:780, w:140, h:28}
            {x:1700, y:680, w:180, h:28}
            {x:1500, y:560, w:160, h:28}
        ]
        coins: [
            {x:400, y:790}, {x:620, y:720}, {x:840, y:790},
            {x:1070, y:720}, {x:1300, y:640}, {x:1550, y:720},
            {x:1760, y:620}, {x:1560, y:500}
        ]
        spikes: [
            {x:300, y:890, w:50, h:30},
            {x:520, y:890, w:50, h:30},
            {x:740, y:890, w:50, h:30},
            {x:960, y:890, w:50, h:30},
            {x:1200, y:890, w:40, h:30},
            {x:1450, y:890, w:40, h:30}
        ]
        goal: {x:1550, y:480, w:60, h:80}
    })

    ' Level 4 - Climb
    levels.push({
        name: "The Climb"
        startX: 100
        startY: 850
        platforms: [
            {x:0, y:950, w:300, h:130}
            {x:380, y:870, w:140, h:26}
            {x:600, y:790, w:140, h:26}
            {x:820, y:710, w:140, h:26}
            {x:1040, y:630, w:140, h:26}
            {x:1260, y:710, w:140, h:26}
            {x:1480, y:630, w:150, h:26}
            {x:1680, y:540, w:160, h:26}
            {x:1450, y:440, w:150, h:26}
            {x:1200, y:360, w:160, h:26}
        ]
        coins: [
            {x:430, y:810}, {x:650, y:730}, {x:870, y:650},
            {x:1090, y:570}, {x:1310, y:650}, {x:1530, y:570},
            {x:1740, y:480}, {x:1510, y:380}, {x:1260, y:300}
        ]
        spikes: [
            {x:320, y:920, w:50, h:30},
            {x:550, y:920, w:40, h:30},
            {x:780, y:920, w:40, h:30},
            {x:1000, y:920, w:40, h:30},
            {x:1220, y:920, w:40, h:30},
            {x:1440, y:920, w:40, h:30},
            {x:1650, y:920, w:50, h:30}
        ]
        goal: {x:1250, y:280, w:60, h:80}
    })

    ' Level 5 - Finale
    levels.push({
        name: "Final Stretch"
        startX: 100
        startY: 850
        platforms: [
            {x:0, y:950, w:280, h:130}
            {x:350, y:870, w:150, h:26}
            {x:580, y:790, w:140, h:26}
            {x:800, y:870, w:140, h:26}
            {x:1020, y:790, w:140, h:26}
            {x:1240, y:710, w:150, h:26}
            {x:1480, y:790, w:140, h:26}
            {x:1680, y:700, w:160, h:26}
            {x:1450, y:590, w:150, h:26}
            {x:1200, y:500, w:160, h:26}
            {x:950, y:410, w:180, h:26}
            {x:700, y:500, w:150, h:26}
            {x:450, y:410, w:160, h:26}
        ]
        coins: [
            {x:400, y:810}, {x:630, y:730}, {x:850, y:810},
            {x:1070, y:730}, {x:1290, y:650}, {x:1530, y:730},
            {x:1740, y:640}, {x:1510, y:530}, {x:1260, y:440},
            {x:1020, y:350}, {x:760, y:440}, {x:510, y:350}
        ]
        spikes: [
            {x:300, y:920, w:40, h:30},
            {x:520, y:920, w:50, h:30},
            {x:760, y:920, w:40, h:30},
            {x:980, y:920, w:40, h:30},
            {x:1200, y:920, w:40, h:30},
            {x:1440, y:920, w:40, h:30},
            {x:1640, y:920, w:50, h:30}
        ]
        goal: {x:500, y:330, w:60, h:80}
    })

    return levels
end function

' ============================================================
' STATE HELPERS
' ============================================================
sub showTitle()
    m.state = "title"
    m.overlay.visible = true
    m.titleLabel.text = "FUN PLATFORMER"
    m.titleLabel.visible = true
    m.msgLabel.text = "Press OK to Start"
    m.msgLabel.visible = true
    m.controlsLabel.visible = true
    m.levelLabel.text = ""
end sub

sub startLevel(idx as Integer)
    if idx < 0 or idx >= m.levels.count() then
        showComplete()
        return
    end if

    m.currentLevel = idx
    level = m.levels[idx]

    ' Clear previous world objects
    while m.world.getChildCount() > 0
        m.world.removeChildIndex(0)
    end while

    ' Platforms
    m.platforms = []
    for each p in level.platforms
        rect = CreateObject("roSGNode", "Rectangle")
        rect.width = p.w
        rect.height = p.h
        rect.translation = [p.x, p.y]
        rect.color = "0x4a90d9"
        m.world.appendChild(rect)
        m.platforms.push({x:p.x, y:p.y, w:p.w, h:p.h, node:rect})
    end for

    ' Coins
    m.coins = []
    for each c in level.coins
        coin = CreateObject("roSGNode", "Rectangle")
        coin.width = 28
        coin.height = 28
        coin.translation = [c.x, c.y]
        coin.color = "0xffd700"
        m.world.appendChild(coin)
        m.coins.push({x:c.x, y:c.y, w:28, h:28, node:coin, collected:false})
    end for

    ' Spikes
    m.spikes = []
    for each s in level.spikes
        spike = CreateObject("roSGNode", "Rectangle")
        spike.width = s.w
        spike.height = s.h
        spike.translation = [s.x, s.y]
        spike.color = "0xff3333"
        m.world.appendChild(spike)
        m.spikes.push({x:s.x, y:s.y, w:s.w, h:s.h})
    end for

    ' Goal
    g = level.goal
    m.goal = {x:g.x, y:g.y, w:g.w, h:g.h}
    goalNode = CreateObject("roSGNode", "Rectangle")
    goalNode.width = g.w
    goalNode.height = g.h
    goalNode.translation = [g.x, g.y]
    goalNode.color = "0x00ff66"
    m.world.appendChild(goalNode)

    ' Flag pole look
    pole = CreateObject("roSGNode", "Rectangle")
    pole.width = 8
    pole.height = g.h + 20
    pole.translation = [g.x + g.w/2 - 4, g.y - 20]
    pole.color = "0xffffff"
    m.world.appendChild(pole)

    ' Reset player
    m.px = level.startX
    m.py = level.startY
    m.vx = 0
    m.vy = 0
    m.onGround = false
    m.player.translation = [m.px, m.py]
    m.player.color = "0x00ff9f"

    ' UI
    m.overlay.visible = false
    m.titleLabel.visible = false
    m.msgLabel.visible = false
    m.controlsLabel.visible = false
    m.levelLabel.text = "Level " + (idx + 1).toStr() + ": " + level.name
    updateHUD()
    m.state = "playing"
end sub

sub showDead()
    m.state = "dead"
    m.overlay.visible = true
    m.titleLabel.text = "OUCH!"
    m.titleLabel.visible = true
    m.msgLabel.text = "Press OK to retry  |  Lives left: " + m.lives.toStr()
    m.msgLabel.visible = true
    m.controlsLabel.visible = false
end sub

sub showWon()
    m.state = "won"
    m.overlay.visible = true
    m.titleLabel.text = "LEVEL CLEAR!"
    m.titleLabel.visible = true
    m.msgLabel.text = "Press OK for next level"
    m.msgLabel.visible = true
    m.controlsLabel.visible = false
end sub

sub showComplete()
    m.state = "complete"
    m.overlay.visible = true
    m.titleLabel.text = "YOU WIN!"
    m.titleLabel.visible = true
    m.msgLabel.text = "Final Score: " + m.score.toStr() + "   Press OK to play again"
    m.msgLabel.visible = true
    m.controlsLabel.visible = false
end sub

sub updateHUD()
    m.scoreLabel.text = "Score: " + m.score.toStr()
    m.livesLabel.text = "Lives: " + m.lives.toStr()
end sub

' ============================================================
' GAME LOOP
' ============================================================
sub onTick()
    if m.state <> "playing" then return

    ' Horizontal movement
    if m.keys["left"] then
        m.vx = -m.moveSpeed
        m.facing = -1
    else if m.keys["right"] then
        m.vx = m.moveSpeed
        m.facing = 1
    else
        m.vx = m.vx * m.friction
        if Abs(m.vx) < 0.3 then m.vx = 0
    end if

    ' Gravity
    m.vy = m.vy + m.gravity
    if m.vy > 20 then m.vy = 20

    ' Apply velocity
    newX = m.px + m.vx
    newY = m.py + m.vy

    ' Collision with platforms (AABB)
    m.onGround = false
    pw = 40
    ph = 50

    for each p in m.platforms
        ' Check if landing on top
        if m.vy >= 0 then
            if newX + pw > p.x and newX < p.x + p.w then
                if m.py + ph <= p.y + 5 and newY + ph >= p.y then
                    newY = p.y - ph
                    m.vy = 0
                    m.onGround = true
                end if
            end if
        end if

        ' Head bump
        if m.vy < 0 then
            if newX + pw > p.x and newX < p.x + p.w then
                if m.py >= p.y + p.h - 5 and newY <= p.y + p.h then
                    newY = p.y + p.h
                    m.vy = 0
                end if
            end if
        end if

        ' Side collision
        if newY + ph > p.y + 5 and newY < p.y + p.h - 5 then
            if m.vx > 0 and m.px + pw <= p.x + 2 and newX + pw >= p.x then
                newX = p.x - pw
                m.vx = 0
            else if m.vx < 0 and m.px >= p.x + p.w - 2 and newX <= p.x + p.w then
                newX = p.x + p.w
                m.vx = 0
            end if
        end if
    end for

    ' World bounds
    if newX < 0 then newX = 0
    if newX > 1880 then newX = 1880
    if newY > 1200 then
        ' Fell off
        die()
        return
    end if

    m.px = newX
    m.py = newY
    m.player.translation = [m.px, m.py]

    ' Coin collection
    for each c in m.coins
        if not c.collected then
            if aabb(m.px, m.py, 40, 50, c.x, c.y, c.w, c.h) then
                c.collected = true
                c.node.visible = false
                m.score = m.score + 100
                updateHUD()
            end if
        end if
    end for

    ' Spikes
    for each s in m.spikes
        if aabb(m.px, m.py, 40, 50, s.x, s.y, s.w, s.h) then
            die()
            return
        end if
    end for

    ' Goal
    if aabb(m.px, m.py, 40, 50, m.goal.x, m.goal.y, m.goal.w, m.goal.h) then
        m.score = m.score + 500
        updateHUD()
        showWon()
    end if
end sub

function aabb(x1, y1, w1, h1, x2, y2, w2, h2) as Boolean
    return x1 < x2 + w2 and x1 + w1 > x2 and y1 < y2 + h2 and y1 + h1 > y2
end function

sub die()
    m.lives = m.lives - 1
    updateHUD()
    m.player.color = "0xff4444"
    if m.lives <= 0 then
        m.state = "complete"
        m.overlay.visible = true
        m.titleLabel.text = "GAME OVER"
        m.titleLabel.visible = true
        m.msgLabel.text = "Score: " + m.score.toStr() + "   Press OK to restart"
        m.msgLabel.visible = true
    else
        showDead()
    end if
end sub

sub doJump()
    if m.state = "playing" and m.onGround then
        m.vy = m.jumpPower
        m.onGround = false
    end if
end sub

' ============================================================
' INPUT
' ============================================================
function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false

    if press then
        if key = "left" then
            m.keys["left"] = true
            handled = true
        else if key = "right" then
            m.keys["right"] = true
            handled = true
        else if key = "up" or key = "OK" or key = "A" or key = "play" then
            if m.state = "title" then
                m.lives = 3
                m.score = 0
                startLevel(0)
            else if m.state = "dead" then
                startLevel(m.currentLevel)
            else if m.state = "won" then
                startLevel(m.currentLevel + 1)
            else if m.state = "complete" then
                m.lives = 3
                m.score = 0
                startLevel(0)
            else if m.state = "playing" then
                doJump()
            end if
            handled = true
        else if key = "B" or key = "replay" or key = "options" then
            ' Restart current level
            if m.state = "playing" or m.state = "dead" then
                startLevel(m.currentLevel)
            end if
            handled = true
        else if key = "back" then
            if m.state = "playing" then
                showTitle()
            else
                ' Let firmware handle exit
                return false
            end if
            handled = true
        end if
    else
        ' Key release
        if key = "left" then
            m.keys["left"] = false
            handled = true
        else if key = "right" then
            m.keys["right"] = false
            handled = true
        end if
    end if

    return handled
end function
